package com.dw.fristapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FristappApplicationTests {

	@Test
	void contextLoads() {
	}

}
