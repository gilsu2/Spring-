package com.dw.fristapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FristappApplication {

	public static void main(String[] args) {
		SpringApplication.run(FristappApplication.class, args);
	}

}
